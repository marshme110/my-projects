"use strict";
(self.__LOADABLE_LOADED_CHUNKS__ = self.__LOADABLE_LOADED_CHUNKS__ || []).push([
    [1907], {
        "6rry": (e, t, n) => {
            n.r(t), n.d(t, {
                default: () => O
            });
            var r, a = n("RlfA"),
                i = n("q1tI"),
                o = n("TRpf"),
                u = n("17x9"),
                l = n.n(u),
                d = n("vOnD"),
                s = n("lXQd"),
                c = n("j399"),
                f = n("HMsx"),
                g = n("T9qK"),
                p = n("P62M"),
                v = n("Mifg"),
                h = function(e, t, n) {
                    return [{
                        key: v.O6.SIGNIN,
                        src: "",
                        activePages: [],
                        title: n.LOGIN_TITLE || v.O6.SIGNIN,
                        fnOnClick: e
                    }, {
                        key: v.O6.SIGNUP,
                        src: "",
                        activePages: [],
                        title: n.SIGNUP_TITLE || v.O6.SIGNUP,
                        fnOnClick: t
                    }]
                },
                m = function(e, t) {
                    return [{
                        key: v.O6.ADDRESTAURANT,
                        src: "",
                        activePages: [],
                        title: e || v.O6.ADDRESTAURANT,
                        fnOnClick: t
                    }]
                },
                b = function(e, t) {
                    return [{
                        key: v.O6.INVESTOR_RELATIONS,
                        src: "",
                        activePages: [],
                        title: e || v.O6.INVESTOR_RELATIONS,
                        fnOnClick: t
                    }]
                },
                w = function(e) {
                    var t = e.handleSignin,
                        n = e.handleSignup,
                        r = e.locale,
                        a = e.currentPageSubType,
                        o = e.breadcrumbs,
                        u = e.transparentPages,
                        l = e.showZomatoLogo,
                        d = e.showAddRestaurant,
                        s = e.addRestaurantText,
                        c = e.handleAddRestaurantClick,
                        f = e.showInvestorRelations,
                        p = e.investorRelationsText,
                        v = e.handleInvestorRelationsClick,
                        w = function(e, t) {
                            var n = "restaurant" === t ? 2 : 3,
                                r = e[e.length - n] || {},
                                a = r.url,
                                i = void 0 === a ? "" : a,
                                o = r.title;
                            return {
                                text: void 0 === o ? "" : o,
                                link: i
                            }
                        }(o, a);
                    return i.createElement(y, null, i.createElement(g.Z, {
                        transparentPages: u,
                        navbarLinks: h(t, n, r),
                        addRestaurantNavLink: m(s, c),
                        showAddRestaurant: d,
                        investorRelationsNavLink: b(p, v),
                        showInvestorRelations: f,
                        backToSearchPageDetails: w,
                        showZomatoLogo: l
                    }))
                },
                y = d.default.div(r || (r = (0, a.Z)(["\n  box-shadow: inset 0px -0.5px 0px ", ";\n"])), f.default.z200);
            w.propTypes = {
                handleSignin: l().func,
                handleSignup: l().func,
                locale: l().objectOf(l().string),
                breadcrumbs: l().arrayOf(l().object),
                currentPageSubType: l().string,
                transparentPages: l().arrayOf(l().string),
                showZomatoLogo: l().bool,
                showAddRestaurant: l().bool,
                addRestaurantText: l().string,
                handleAddRestaurantClick: l().func,
                showInvestorRelations: l().bool,
                investorRelationsText: l().string,
                handleInvestorRelationsClick: l().func
            }, w.defaultProps = {
                handleSignin: c.default,
                handleSignup: c.default,
                locale: {},
                breadcrumbs: [],
                currentPageSubType: "",
                transparentPages: [],
                showZomatoLogo: !0,
                showAddRestaurant: !1,
                addRestaurantText: "",
                handleAddRestaurantClick: c.default,
                showInvestorRelations: !1,
                investorRelationsText: "",
                handleInvestorRelationsClick: c.default
            };
            const O = (0, o.$j)((function(e) {
                var t = (0, s.default)(e, "pages.current.resId", 0);
                return {
                    breadcrumbs: (0, s.default)(e, "pages.restaurant.".concat(t, ".sections.SECTION_BREADCRUMBS"), []),
                    currentPageSubType: (0, s.default)(e, "pages.current.subType", ""),
                    locale: (0, s.default)(e, "langKeys", {})
                }
            }), null)((0, i.memo)(w, p.Uh))
        },
        kdDk: (e, t, n) => {
            var r = n("JMD1");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var a = r(n("2qDD")).default;
            t.default = a
        },
        cjht: (e, t, n) => {
            var r = n("JMD1"),
                a = n("YovJ");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = r(n("pP/M")),
                o = function(e, t) {
                    if (!t && e && e.__esModule) return e;
                    if (null === e || "object" !== a(e) && "function" != typeof e) return {
                        default: e
                    };
                    var n = s(t);
                    if (n && n.has(e)) return n.get(e);
                    var r = {},
                        i = Object.defineProperty && Object.getOwnPropertyDescriptor;
                    for (var o in e)
                        if ("default" !== o && Object.prototype.hasOwnProperty.call(e, o)) {
                            var u = i ? Object.getOwnPropertyDescriptor(e, o) : null;
                            u && (u.get || u.set) ? Object.defineProperty(r, o, u) : r[o] = e[o]
                        }
                    r.default = e, n && n.set(e, r);
                    return r
                }(n("q1tI")),
                u = r(n("17x9")),
                l = r(n("vOnD")),
                d = r(n("j399"));

            function s(e) {
                if ("function" != typeof WeakMap) return null;
                var t = new WeakMap,
                    n = new WeakMap;
                return (s = function(e) {
                    return e ? n : t
                })(e)
            }
            var c = function e(t) {
                var n = (0, o.useRef)(),
                    r = t.handleClickOutside,
                    a = t.removeHandler;
                return (0, o.useEffect)((function() {
                    if ("function" == typeof r && !a) {
                        var e = function(e) {
                            n.current && n.current.contains(e.target) || r(e)
                        };
                        return document.addEventListener("mousedown", e),
                            function() {
                                document.removeEventListener("mousedown", e)
                            }
                    }
                    return d.default
                }), [r, a]), o.default.createElement(e.Wrapper, (0, i.default)({}, t, {
                    ref: n
                }), t.children)
            };
            c.Wrapper = l.default.div.withConfig({
                componentId: "sc-18n4g8v-0"
            })(["width:", ";"], (function(e) {
                return e.width ? e.width : "max-content"
            })), c.propTypes = {
                width: u.default.string,
                children: u.default.node,
                handleClickOutside: u.default.func.isRequired,
                removeHandler: u.default.bool
            }, c.defaultProps = {
                removeHandler: !1
            };
            var f = c;
            t.default = f
        },
        PQmA: (e, t, n) => {
            var r = n("JMD1");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var a = r(n("pP/M")),
                i = r(n("q1tI")),
                o = r(n("w/pp")),
                u = r(n("6jlT")),
                l = function(e) {
                    var t = (0, u.default)();
                    return i.default.createElement(o.default, (0, a.default)({
                        uniqueId: t
                    }, e), i.default.createElement("title", null, "chevron-down"), i.default.createElement("path", {
                        d: "M4.48 7.38c0.28-0.28 0.76-0.28 1.060 0l4.46 4.48 4.48-4.48c0.28-0.28 0.76-0.28 1.060 0s0.28 0.78 0 1.060l-5 5c-0.3 0.3-0.78 0.3-1.060 0l-5-5c-0.3-0.28-0.3-0.76 0-1.060z"
                    }))
                };
            t.default = l
        },
        "30GX": (e, t, n) => {
            var r = n("JMD1"),
                a = n("YovJ");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = r(n("Kq5O")),
                o = r(n("YOv7")),
                u = r(n("UNXm")),
                l = v(n("q1tI")),
                d = v(n("vOnD")),
                s = r(n("17x9")),
                c = r(n("HMsx")),
                f = r(n("LSsp")),
                g = r(n("j399"));

            function p(e) {
                if ("function" != typeof WeakMap) return null;
                var t = new WeakMap,
                    n = new WeakMap;
                return (p = function(e) {
                    return e ? n : t
                })(e)
            }

            function v(e, t) {
                if (!t && e && e.__esModule) return e;
                if (null === e || "object" !== a(e) && "function" != typeof e) return {
                    default: e
                };
                var n = p(t);
                if (n && n.has(e)) return n.get(e);
                var r = {},
                    i = Object.defineProperty && Object.getOwnPropertyDescriptor;
                for (var o in e)
                    if ("default" !== o && Object.prototype.hasOwnProperty.call(e, o)) {
                        var u = i ? Object.getOwnPropertyDescriptor(e, o) : null;
                        u && (u.get || u.set) ? Object.defineProperty(r, o, u) : r[o] = e[o]
                    }
                return r.default = e, n && n.set(e, r), r
            }
            var h = function(e) {
                    return new Promise((function(t, n) {
                        var r = new Image;
                        r.onload = function() {
                            t()
                        }, r.src = e
                    }))
                },
                m = function e(t) {
                    var r = t.src,
                        a = void 0 === r ? "" : r,
                        d = t.base64,
                        s = void 0 === d ? "" : d,
                        c = t.ratio,
                        f = void 0 === c ? 0 : c,
                        p = t.container,
                        v = void 0 === p ? null : p,
                        m = t.alt,
                        w = void 0 === m ? "image" : m,
                        y = t.fit,
                        O = void 0 === y ? "cover" : y,
                        k = t.doPreload,
                        I = void 0 !== k && k,
                        P = t.height,
                        R = void 0 === P ? "100%" : P,
                        T = t.width,
                        S = void 0 === T ? "100%" : T,
                        C = t.className,
                        _ = void 0 === C ? "" : C,
                        E = t.onClick,
                        L = void 0 === E ? g.default : E,
                        D = (t.srcSet, t.fallBack),
                        j = void 0 === D ? "https://b.zmtcdn.com/images/placeholder_200.png?output-quality=70" : D,
                        M = t.isBackground,
                        A = void 0 !== M && M,
                        x = (t.bgGradient, t.customZimageComponent),
                        N = void 0 === x ? null : x,
                        z = t.loadingComponent,
                        G = void 0 === z ? null : z,
                        q = t.blurred,
                        H = void 0 === q ? "" : q,
                        W = t.noTransform,
                        B = void 0 !== W && W,
                        U = t.clickable,
                        Z = void 0 !== U && U,
                        J = (0, l.useRef)(),
                        K = (0, l.useState)(""),
                        X = (0, u.default)(K, 2),
                        Y = X[0],
                        Q = X[1],
                        V = (0, l.useState)(!1),
                        F = (0, u.default)(V, 2),
                        $ = F[0],
                        ee = F[1],
                        te = (0, l.useState)(!1),
                        ne = (0, u.default)(te, 2),
                        re = (ne[0], ne[1]),
                        ae = function() {
                            H && oe(), ee(!0)
                        },
                        ie = function() {
                            re(!0), Y && Y !== j && Q(j)
                        };
                    (0, l.useEffect)((function() {
                        if (A && Y) {
                            var e = new Image;
                            e.onload = ae, e.onerror = ie, e.src = Y
                        }
                        $ && ee(!1)
                    }), [Y]), (0, l.useEffect)((function() {
                        var e, t;
                        if (!I && "IntersectionObserver" in n.g) {
                            e = new IntersectionObserver((function(e) {
                                var t = (0, u.default)(e, 1)[0].isIntersecting;
                                void 0 !== t && t && Y !== a && Q(a)
                            }), {
                                root: v,
                                threshold: f
                            }), (t = J.current) && e.observe(t)
                        } else Q(a);
                        return function() {
                            void 0 !== e && e.unobserve && t && e.unobserve(t)
                        }
                    }), [a]);
                    var oe = function() {
                            var e = (0, o.default)(i.default.mark((function e() {
                                return i.default.wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            return e.next = 2, h(Y);
                                        case 2:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e)
                            })));
                            return function() {
                                return e.apply(this, arguments)
                            }
                        }(),
                        ue = A ? N || e.BgDiv : e.img,
                        le = s ? e.base64 : G || e.Shimmer;
                    return l.default.createElement(e.Container, {
                        ref: J,
                        height: R,
                        width: S,
                        className: _,
                        onClick: L
                    }, H ? l.default.createElement(b, {
                        imgHeight: R,
                        imgWidth: S,
                        url: H,
                        fit: O
                    }) : l.default.createElement(le, {
                        isLoaded: !!Y && $,
                        src: s
                    }), l.default.createElement(ue, {
                        alt: w,
                        src: Y,
                        isLoaded: !!Y && $,
                        onLoad: ae,
                        loading: I ? "auto" : "lazy",
                        fit: O,
                        onError: ie,
                        noTransform: B || !!H,
                        blurred: !!H,
                        clickable: !!Z
                    }))
                };
            m.propTypes = {
                src: s.default.string,
                base64: s.default.string,
                ratio: s.default.number,
                container: s.default.node,
                alt: s.default.string.isRequired,
                fit: s.default.oneOf(["cover", "contain", "fill", "inherit", "initial", "none", "scale-down", "unset"]),
                doPreload: s.default.bool,
                height: s.default.string,
                width: s.default.string,
                maxHeight: s.default.string,
                className: s.default.string,
                onClick: s.default.func,
                fallBack: s.default.string,
                isBackground: s.default.bool,
                bgGradient: s.default.string,
                customZimageComponent: s.default.oneOfType([s.default.string, s.default.func]),
                loadingComponent: s.default.oneOfType([s.default.string, s.default.func]),
                noTransform: s.default.bool,
                blurred: s.default.string
            };
            var b = d.default.div.withConfig({
                componentId: "sc-s1isp7-0"
            })(["position:absolute;top:0;background-image:url(", ");width:", ";height:", ";background-size:", ";filter:blur(10px);"], (function(e) {
                return e.url
            }), (function(e) {
                return e.imgWidth
            }), (function(e) {
                return e.imgHeight
            }), (function(e) {
                return "none" === e.fit ? "".concat(e.imgWidth, " ").concat(e.imgHeight || "auto") : e.fit
            }));
            m.Container = d.default.div.withConfig({
                componentId: "sc-s1isp7-1"
            })(["position:relative;max-width:100%;width:", ";height:", ";overflow:hidden;"], (function(e) {
                return e.width
            }), (function(e) {
                return e.height ? e.height : "auto"
            }));
            var w = (0, d.keyframes)(["0%{background-position:-80vw 0;}100%{background-position:80vw 0;}"]);
            m.base64 = d.default.img.withConfig({
                componentId: "sc-s1isp7-2"
            })(["position:absolute;top:0;left:0;width:100%;height:100%;opacity:", ";will-change:transform,opacity;border-radius:inherit;transition:opacity 0.25s ease-in;"], (function(e) {
                return e.isLoaded ? 0 : 1
            })), m.Shimmer = d.default.div.withConfig({
                componentId: "sc-s1isp7-3"
            })(["width:100%;position:absolute;top:0;left:0;height:100%;background:", ";background-image:linear-gradient( to right,", " 0%,", " 10%,", " 40%,", " 100% );background-repeat:no-repeat;opacity:", ";transition:opacity 0.25s ease-out;will-change:opacity;border-radius:inherit;animation:", " 1.5s infinite linear forwards;"], c.default.z95, c.default.z95, f.default, c.default.z95, c.default.z95, (function(e) {
                return e.isLoaded ? 0 : 1
            }), w), m.BgDiv = d.default.div.withConfig({
                componentId: "sc-s1isp7-4"
            })(["width:100%;height:100%;transform:", ";opacity:", ";will-change:transform,opacity;border-radius:inherit;transition:opacity 0.25s ease,transform 0.25s ease;background-size:", ";background-position:center center;background-repeat:no-repeat;background-image:", ";"], (function(e) {
                return e.isLoaded || e.noTransform ? "none" : "scale(0.9)"
            }), (function(e) {
                return e.isLoaded ? 1 : 0
            }), (function(e) {
                return e.fit || "cover"
            }), (function(e) {
                return e.url && (e.bgGradient ? "".concat(e.bgGradient, ",url(").concat(e.url, ")") : "url(".concat(e.url, ")"))
            }));
            m.img = d.default.img.withConfig({
                componentId: "sc-s1isp7-5"
            })(["width:100%;height:100%;object-fit:", ";transform:", ";opacity:", ";will-change:transform,opacity;border-radius:inherit;filter:", ";transition:", ";:hover{transform:", ";filter:", ";}img:not([src]):not([srcset]){visibility:hidden;}@-moz-document url-prefix(){img:-moz-loading{visibility:hidden;}}"], (function(e) {
                return e.fit
            }), (function(e) {
                return e.isLoaded || e.noTransform ? "none" : "scale(0.9)"
            }), (function(e) {
                return e.isLoaded ? 1 : 0
            }), (function(e) {
                return e.clickable ? "brightness(0.95)" : "unset"
            }), (function(e) {
                var t = e.clickable,
                    n = e.blurred;
                return t && n ? "transform 0.4s ease-in-out, opacity 1.63s ease, filter 0.4s ease" : t ? "transform 0.4s ease-in-out, filter 0.4s ease, opacity 0.25s ease" : n ? "opacity 1.63s ease, transform 0.25s ease" : "opacity 0.25s ease, transform 0.25s ease"
            }), (function(e) {
                return e.clickable ? "scale(1.05)" : ""
            }), (function(e) {
                return e.clickable ? "brightness(1.05)" : ""
            }));
            var y = m;
            t.default = y
        },
        lFeK: (e, t, n) => {
            var r = n("JMD1");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var a = r(n("30GX")).default;
            t.default = a
        }
    }
]);