import React from "react";
import Home from "./Home";

function Main() {
  return (
    <div>
      <Home />
    </div>
  );
}

export default Main;
